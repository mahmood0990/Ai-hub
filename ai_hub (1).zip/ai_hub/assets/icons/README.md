# App icons (optional)

The app shows a modern gradient icon for every tool by default.
If you'd like to show the official icon instead, put a square PNG
(around 192×192) in this folder named after the app id:

chatgpt.png · claude.png · gemini.png · copilot.png · perplexity.png ·
designer.png · elevenlabs.png · capcut.png · notion.png · grammarly.png ·
characterai.png · socratic.png · quillbot.png · deepl.png · huggingface.png

Missing files automatically fall back to the gradient icon.
