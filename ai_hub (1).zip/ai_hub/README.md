# AI Hub — بوابة الذكاء الاصطناعي

تطبيق Flutter ثنائي اللغة (عربي / إنجليزي) يعرض 15 تطبيق ذكاء اصطناعي.
عند الضغط على أي تطبيق: إذا كان مثبّتاً يُفتح مباشرة، وإذا لم يكن مثبّتاً تُفتح صفحته في Google Play.

## هيكل المشروع

```
ai_hub/
├── pubspec.yaml
├── lib/
│   ├── main.dart                      ← نقطة البداية + اللغات + الثيم
│   ├── l10n/app_strings.dart          ← النصوص العربية/الإنجليزية + حفظ اللغة
│   ├── theme/app_theme.dart           ← الألوان والخطوط (Cairo / Outfit)
│   ├── models/ai_app.dart             ← نموذج بيانات التطبيق
│   ├── data/ai_apps.dart              ← بيانات الـ 15 تطبيق وأسماء الحزم
│   ├── services/app_launcher_service.dart ← منطق: مثبّت؟ افتحه : افتح المتجر
│   ├── screens/splash_screen.dart     ← شاشة الترحيب
│   ├── screens/home_screen.dart       ← الشاشة الرئيسية (بحث + تصنيفات + شبكة)
│   └── widgets/                       ← الخلفية المتحركة، الشعار، البطاقات…
├── android/app/src/main/
│   ├── AndroidManifest.xml            ← قائمة <queries> المطلوبة لأندرويد 11+
│   └── kotlin/com/aihub/ai_hub/MainActivity.kt ← كود أصلي: فحص التثبيت والفتح
├── assets/icons/                      ← (اختياري) ضع الأيقونات الرسمية هنا
└── .github/workflows/build-apk.yml    ← بناء APK تلقائياً على GitHub
```

## أسماء الحزم (Package Names)

| التطبيق | Package |
|---|---|
| ChatGPT | com.openai.chatgpt |
| Claude | com.anthropic.claude |
| Google Gemini | com.google.android.apps.bard |
| Microsoft Copilot | com.microsoft.copilot |
| Perplexity AI | ai.perplexity.app.android |
| Microsoft Designer | com.microsoft.designer |
| ElevenLabs | io.elevenlabs.coreapp |
| CapCut | com.lemon.lvoverseas |
| Notion | notion.id |
| Grammarly | com.grammarly.android.keyboard |
| Character.ai | ai.character.app |
| Socratic by Google | com.google.socratic |
| QuillBot | com.quillbot.mobile |
| DeepL Translate | com.deepl.mobiletranslator |
| Hugging Face | (لا يوجد تطبيق أندرويد رسمي ← يفتح huggingface.co/chat) |

## الطريقة 1: بناء APK بدون تثبيت أي شيء (GitHub Actions)

1. أنشئ مستودعاً جديداً على GitHub وارفع إليه محتويات مجلد `ai_hub`.
2. افتح تبويب **Actions** ← سيبدأ **Build APK** تلقائياً (أو اضغط Run workflow).
3. بعد انتهائه (5–8 دقائق تقريباً) حمّل الملف من قسم **Artifacts** باسم `ai-hub-apk`.

## الطريقة 2: البناء على جهازك

```bash
# 1) ثبّت Flutter: https://docs.flutter.dev/get-started/install
cd ai_hub
# 2) أكمل ملفات أندرويد الناقصة (لن يستبدل ملفاتنا الموجودة)
flutter create --org com.aihub --project-name ai_hub --platforms android .
# 3) نزّل الحزم وابنِ
flutter pub get
flutter build apk --release
```
الملف الناتج: `build/app/outputs/flutter-apk/app-release.apk`

> ملاحظة: نسخة release تُوقَّع افتراضياً بمفتاح debug، وهذا كافٍ للتثبيت على الهاتف.
> للنشر على Google Play أنشئ مفتاح توقيع خاص بك.
