import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Animated AI logo: a glowing core, a rotating gradient ring and
/// three orbiting "neurons".
class AiLogo extends StatefulWidget {
  const AiLogo({super.key, this.size = 150});
  final double size;

  @override
  State<AiLogo> createState() => _AiLogoState();
}

class _AiLogoState extends State<AiLogo> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 8),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    return SizedBox(
      width: s,
      height: s,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final a = _c.value * 2 * math.pi;
          final pulse = 1 + 0.04 * math.sin(a * 2);
          return Stack(
            alignment: Alignment.center,
            children: [
              // soft glow
              Container(
                width: s * 0.9,
                height: s * 0.9,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primary.withValues(alpha: 0.35),
                      blurRadius: s * 0.35,
                      spreadRadius: s * 0.02,
                    ),
                  ],
                ),
              ),
              // rotating ring
              Transform.rotate(
                angle: a,
                child: CustomPaint(
                  size: Size.square(s),
                  painter: _RingPainter(),
                ),
              ),
              // orbiting neurons
              for (int i = 0; i < 3; i++)
                Transform.translate(
                  offset: Offset(
                    math.cos(-a * 1.5 + i * 2 * math.pi / 3) * s * 0.42,
                    math.sin(-a * 1.5 + i * 2 * math.pi / 3) * s * 0.42,
                  ),
                  child: Container(
                    width: s * 0.07,
                    height: s * 0.07,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: [
                        AppColors.secondary,
                        AppColors.accent,
                        AppColors.primary
                      ][i],
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.secondary.withValues(alpha: 0.6),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                  ),
                ),
              // core
              Transform.scale(
                scale: pulse,
                child: Container(
                  width: s * 0.56,
                  height: s * 0.56,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: AppColors.brandGradient,
                  ),
                  child: Icon(
                    Icons.auto_awesome_rounded,
                    size: s * 0.28,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.025
      ..strokeCap = StrokeCap.round
      ..shader = const SweepGradient(
        colors: [
          Colors.transparent,
          AppColors.secondary,
          AppColors.primary,
          AppColors.accent,
          Colors.transparent,
        ],
      ).createShader(rect);
    canvas.drawArc(rect.deflate(size.width * 0.08), 0, math.pi * 1.6, false,
        paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
