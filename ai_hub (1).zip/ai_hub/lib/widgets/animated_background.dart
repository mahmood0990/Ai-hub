import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Calm, slowly drifting glowing orbs on a deep navy gradient.
class AnimatedBackground extends StatefulWidget {
  const AnimatedBackground({super.key, this.child});
  final Widget? child;

  @override
  State<AnimatedBackground> createState() => _AnimatedBackgroundState();
}

class _AnimatedBackgroundState extends State<AnimatedBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 24),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [AppColors.bg, AppColors.bgDeep],
            ),
          ),
        ),
        RepaintBoundary(
          child: AnimatedBuilder(
            animation: _c,
            builder: (_, __) => CustomPaint(painter: _OrbPainter(_c.value)),
          ),
        ),
        const CustomPaint(painter: _DotGridPainter()),
        if (widget.child != null) widget.child!,
      ],
    );
  }
}

class _OrbPainter extends CustomPainter {
  _OrbPainter(this.t);
  final double t;

  static const _orbs = [
    (color: AppColors.primary, x: 0.15, y: 0.18, r: 0.75, phase: 0.0),
    (color: AppColors.secondary, x: 0.90, y: 0.45, r: 0.65, phase: 2.1),
    (color: AppColors.accent, x: 0.30, y: 0.92, r: 0.70, phase: 4.2),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final a = t * 2 * math.pi;
    for (final o in _orbs) {
      final center = Offset(
        size.width * (o.x + 0.08 * math.sin(a + o.phase)),
        size.height * (o.y + 0.05 * math.cos(a * 0.8 + o.phase)),
      );
      final radius = size.width * o.r;
      final paint = Paint()
        ..shader = RadialGradient(
          colors: [
            o.color.withValues(alpha: 0.22),
            o.color.withValues(alpha: 0.0),
          ],
        ).createShader(Rect.fromCircle(center: center, radius: radius));
      canvas.drawCircle(center, radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _OrbPainter old) => old.t != t;
}

class _DotGridPainter extends CustomPainter {
  const _DotGridPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = Colors.white.withValues(alpha: 0.035);
    const gap = 28.0;
    for (double x = gap / 2; x < size.width; x += gap) {
      for (double y = gap / 2; y < size.height; y += gap) {
        canvas.drawCircle(Offset(x, y), 0.9, p);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
