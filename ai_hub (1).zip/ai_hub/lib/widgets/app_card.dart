import 'package:flutter/material.dart';

import '../l10n/app_strings.dart';
import '../models/ai_app.dart';
import '../theme/app_theme.dart';
import 'glass.dart';

class AppCard extends StatefulWidget {
  const AppCard({
    super.key,
    required this.app,
    required this.installed,
    required this.onTap,
  });

  final AiApp app;
  final bool installed;
  final VoidCallback onTap;

  @override
  State<AppCard> createState() => _AppCardState();
}

class _AppCardState extends State<AppCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final app = widget.app;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapCancel: () => setState(() => _pressed = false),
      onTapUp: (_) => setState(() => _pressed = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _pressed ? 0.95 : 1,
        duration: const Duration(milliseconds: 140),
        child: Glass(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _AppIcon(app: app),
                  const Spacer(),
                  if (widget.installed)
                    const Icon(Icons.check_circle_rounded,
                        size: 18, color: AppColors.success),
                ],
              ),
              const Spacer(),
              Text(
                app.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textDirection: TextDirection.ltr,
                style: const TextStyle(
                  fontSize: 15.5,
                  fontWeight: FontWeight.w700,
                  color: AppColors.text,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                app.description(s.isAr),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 11.5,
                  height: 1.35,
                  color: AppColors.muted,
                ),
              ),
              const SizedBox(height: 10),
              _ActionPill(installed: widget.installed, hasApp: app.packageName != null),
            ],
          ),
        ),
      ),
    );
  }
}

class _AppIcon extends StatelessWidget {
  const _AppIcon({required this.app});
  final AiApp app;

  @override
  Widget build(BuildContext context) {
    final fallback = Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
          colors: app.colors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Icon(app.icon, color: Colors.white, size: 26),
    );

    return Container(
      width: 50,
      height: 50,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: app.colors.first.withValues(alpha: 0.35),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        // If you add assets/icons/<id>.png it is used; otherwise the gradient icon.
        child: Image.asset(
          app.iconAsset,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => fallback,
        ),
      ),
    );
  }
}

class _ActionPill extends StatelessWidget {
  const _ActionPill({required this.installed, required this.hasApp});
  final bool installed;
  final bool hasApp;

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final IconData icon;
    final String label;
    if (installed) {
      icon = Icons.open_in_new_rounded;
      label = s.t('installed');
    } else if (hasApp) {
      icon = Icons.download_rounded;
      label = s.t('notInstalled');
    } else {
      icon = Icons.public_rounded;
      label = 'Web';
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: installed ? AppColors.brandGradient : null,
        color: installed ? null : Colors.white.withValues(alpha: 0.08),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: installed ? AppColors.bg : AppColors.text),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: installed ? AppColors.bg : AppColors.text,
            ),
          ),
        ],
      ),
    );
  }
}
