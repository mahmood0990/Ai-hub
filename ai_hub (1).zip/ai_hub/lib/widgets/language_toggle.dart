import 'package:flutter/material.dart';

import '../l10n/app_strings.dart';
import '../theme/app_theme.dart';
import 'glass.dart';

/// Pill button that switches between Arabic and English.
class LanguageToggle extends StatelessWidget {
  const LanguageToggle({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = LocaleScope.of(context);
    final s = S.of(context);
    return GestureDetector(
      onTap: controller.toggle,
      child: Glass(
        radius: 30,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.language_rounded,
                size: 18, color: AppColors.secondary),
            const SizedBox(width: 6),
            Text(
              s.t('langButton'),
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 13,
                color: AppColors.text,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
