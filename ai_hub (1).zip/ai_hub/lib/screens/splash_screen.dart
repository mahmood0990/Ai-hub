import 'package:flutter/material.dart';

import '../l10n/app_strings.dart';
import '../theme/app_theme.dart';
import '../widgets/ai_logo.dart';
import '../widgets/animated_background.dart';
import '../widgets/language_toggle.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _intro = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1600),
  )..forward();

  Animation<double> _fade(double begin, double end) => CurvedAnimation(
        parent: _intro,
        curve: Interval(begin, end, curve: Curves.easeOutCubic),
      );

  @override
  void dispose() {
    _intro.dispose();
    super.dispose();
  }

  void _start() {
    Navigator.of(context).pushReplacement(PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 700),
      pageBuilder: (_, __, ___) => const HomeScreen(),
      transitionsBuilder: (_, anim, __, child) => FadeTransition(
        opacity: anim,
        child: ScaleTransition(
          scale: Tween(begin: 1.04, end: 1.0)
              .animate(CurvedAnimation(parent: anim, curve: Curves.easeOut)),
          child: child,
        ),
      ),
    ));
  }

  Widget _reveal(double begin, double end, Widget child) {
    final a = _fade(begin, end);
    return FadeTransition(
      opacity: a,
      child: SlideTransition(
        position: Tween(begin: const Offset(0, 0.15), end: Offset.zero)
            .animate(a),
        child: child,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      body: AnimatedBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: Column(
              children: [
                const Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: LanguageToggle(),
                ),
                const Spacer(flex: 2),
                _reveal(0.0, 0.5, const AiLogo(size: 170)),
                const SizedBox(height: 40),
                _reveal(
                  0.25,
                  0.7,
                  ShaderMask(
                    shaderCallback: (r) =>
                        AppColors.brandGradient.createShader(r),
                    child: Text(
                      s.t('welcomeTitle'),
                      textAlign: TextAlign.center,
                      style: textTheme.headlineMedium?.copyWith(
                        fontWeight: FontWeight.w800,
                        height: 1.3,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                _reveal(
                  0.4,
                  0.85,
                  Text(
                    s.t('welcomeSubtitle'),
                    textAlign: TextAlign.center,
                    style: textTheme.bodyMedium?.copyWith(
                      color: AppColors.muted,
                      height: 1.7,
                    ),
                  ),
                ),
                const Spacer(flex: 3),
                _reveal(0.6, 1.0, _GetStartedButton(onTap: _start)),
                const SizedBox(height: 14),
                _reveal(
                  0.7,
                  1.0,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.bolt_rounded,
                          size: 16, color: AppColors.secondary),
                      const SizedBox(width: 4),
                      Text(
                        s.t('toolsCount'),
                        style: const TextStyle(
                            color: AppColors.muted, fontSize: 12.5),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _GetStartedButton extends StatelessWidget {
  const _GetStartedButton({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final isAr = s.isAr;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 58,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: AppColors.brandGradient,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withValues(alpha: 0.45),
              blurRadius: 28,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              s.t('getStarted'),
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: AppColors.bg,
              ),
            ),
            const SizedBox(width: 10),
            Icon(
              isAr ? Icons.arrow_back_rounded : Icons.arrow_forward_rounded,
              color: AppColors.bg,
            ),
          ],
        ),
      ),
    );
  }
}
