import 'package:flutter/material.dart';

import '../data/ai_apps.dart';
import '../l10n/app_strings.dart';
import '../models/ai_app.dart';
import '../services/app_launcher_service.dart';
import '../theme/app_theme.dart';
import '../widgets/animated_background.dart';
import '../widgets/app_card.dart';
import '../widgets/glass.dart';
import '../widgets/language_toggle.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  Set<String> _installed = {};
  String _query = '';
  AppCategory? _category; // null = all

  late final AnimationController _stagger = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1100),
  )..forward();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refreshInstalled();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _stagger.dispose();
    super.dispose();
  }

  // When the user comes back (e.g. after installing from Play), refresh badges.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refreshInstalled();
  }

  Future<void> _refreshInstalled() async {
    final pkgs = aiApps
        .map((a) => a.packageName)
        .whereType<String>()
        .toList(growable: false);
    final installed = await AppLauncherService.installedOf(pkgs);
    if (mounted) setState(() => _installed = installed);
  }

  List<AiApp> get _filtered {
    final q = _query.trim().toLowerCase();
    return aiApps.where((a) {
      final inCat = _category == null || a.category == _category;
      final inSearch = q.isEmpty ||
          a.name.toLowerCase().contains(q) ||
          a.descEn.toLowerCase().contains(q) ||
          a.descAr.contains(q);
      return inCat && inSearch;
    }).toList();
  }

  Future<void> _onTap(AiApp app) async {
    final s = S.of(context);
    final messenger = ScaffoldMessenger.of(context);
    final outcome = await AppLauncherService.open(app);

    final String msg = switch (outcome) {
      LaunchOutcome.openedApp => '${s.t('openingApp')} ${app.name}',
      LaunchOutcome.openedStore => '${s.t('openingStore')} ${app.name}',
      LaunchOutcome.openedWeb => '${s.t('openingWeb')} ${app.name}',
      LaunchOutcome.failed => '${s.t('failed')} ${app.name}',
    };
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(msg),
        duration: const Duration(seconds: 2),
      ));
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final textTheme = Theme.of(context).textTheme;
    final width = MediaQuery.sizeOf(context).width;
    final columns = width >= 900 ? 4 : (width >= 600 ? 3 : 2);
    final apps = _filtered;

    return Scaffold(
      body: AnimatedBackground(
        child: SafeArea(
          bottom: false,
          child: RefreshIndicator(
            onRefresh: _refreshInstalled,
            color: AppColors.secondary,
            backgroundColor: AppColors.bg,
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics()),
              slivers: [
                // ---------- Header ----------
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                  sliver: SliverToBoxAdapter(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                gradient: AppColors.brandGradient,
                                borderRadius: BorderRadius.circular(13),
                              ),
                              child: const Icon(Icons.auto_awesome_rounded,
                                  color: Colors.white, size: 22),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              s.t('appName'),
                              style: textTheme.titleLarge
                                  ?.copyWith(fontWeight: FontWeight.w800),
                            ),
                            const Spacer(),
                            const LanguageToggle(),
                          ],
                        ),
                        const SizedBox(height: 26),
                        Text(
                          s.t('homeTitle'),
                          style: textTheme.headlineSmall?.copyWith(
                            fontWeight: FontWeight.w800,
                            height: 1.25,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          s.t('homeSubtitle'),
                          style: textTheme.bodyMedium
                              ?.copyWith(color: AppColors.muted),
                        ),
                        const SizedBox(height: 20),
                        _SearchField(
                          hint: s.t('search'),
                          onChanged: (v) => setState(() => _query = v),
                        ),
                        const SizedBox(height: 16),
                      ],
                    ),
                  ),
                ),

                // ---------- Category chips ----------
                SliverToBoxAdapter(
                  child: SizedBox(
                    height: 42,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      physics: const BouncingScrollPhysics(),
                      children: [
                        _CategoryChip(
                          label: s.t('cat_all'),
                          selected: _category == null,
                          onTap: () => setState(() => _category = null),
                        ),
                        for (final c in AppCategory.values)
                          _CategoryChip(
                            label: s.t('cat_${c.name}'),
                            selected: _category == c,
                            onTap: () => setState(() => _category = c),
                          ),
                      ],
                    ),
                  ),
                ),

                // ---------- Grid ----------
                if (apps.isEmpty)
                  SliverFillRemaining(
                    hasScrollBody: false,
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.search_off_rounded,
                              size: 48, color: AppColors.muted),
                          const SizedBox(height: 10),
                          Text(s.t('noResults'),
                              style: const TextStyle(color: AppColors.muted)),
                        ],
                      ),
                    ),
                  )
                else
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(20, 18, 20, 40),
                    sliver: SliverGrid(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: columns,
                        mainAxisSpacing: 14,
                        crossAxisSpacing: 14,
                        childAspectRatio: 0.82,
                      ),
                      delegate: SliverChildBuilderDelegate(
                        (context, i) {
                          final app = apps[i];
                          final start = (i * 0.05).clamp(0.0, 0.7);
                          final anim = CurvedAnimation(
                            parent: _stagger,
                            curve: Interval(start, (start + 0.3).clamp(0.0, 1.0),
                                curve: Curves.easeOutCubic),
                          );
                          return FadeTransition(
                            opacity: anim,
                            child: SlideTransition(
                              position: Tween(
                                begin: const Offset(0, 0.2),
                                end: Offset.zero,
                              ).animate(anim),
                              child: AppCard(
                                app: app,
                                installed: app.packageName != null &&
                                    _installed.contains(app.packageName),
                                onTap: () => _onTap(app),
                              ),
                            ),
                          );
                        },
                        childCount: apps.length,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SearchField extends StatelessWidget {
  const _SearchField({required this.hint, required this.onChanged});
  final String hint;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return Glass(
      radius: 18,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: TextField(
        onChanged: onChanged,
        style: const TextStyle(color: AppColors.text),
        cursorColor: AppColors.secondary,
        decoration: InputDecoration(
          icon: const Icon(Icons.search_rounded, color: AppColors.muted),
          hintText: hint,
          hintStyle: const TextStyle(color: AppColors.muted),
          border: InputBorder.none,
        ),
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  const _CategoryChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          padding: const EdgeInsets.symmetric(horizontal: 16),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            gradient: selected ? AppColors.brandGradient : null,
            color: selected ? null : AppColors.glass,
            border: Border.all(
              color: selected ? Colors.transparent : AppColors.glassBorder,
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 13,
              color: selected ? AppColors.bg : AppColors.text,
            ),
          ),
        ),
      ),
    );
  }
}
