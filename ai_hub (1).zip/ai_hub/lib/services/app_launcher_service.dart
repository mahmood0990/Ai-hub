import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/ai_app.dart';

enum LaunchOutcome { openedApp, openedStore, openedWeb, failed }

/// Checks whether an app is installed and opens it, or sends the user to
/// Google Play. Talks to native Android code in MainActivity.kt.
class AppLauncherService {
  static const _channel = MethodChannel('com.aihub/apps');

  /// Returns the subset of [packages] that are installed on the device.
  static Future<Set<String>> installedOf(List<String> packages) async {
    if (defaultTargetPlatform != TargetPlatform.android) return {};
    try {
      final result = await _channel
          .invokeListMethod<String>('installedOf', {'packages': packages});
      return (result ?? const []).toSet();
    } catch (_) {
      return {};
    }
  }

  static Future<bool> isInstalled(String package) async {
    if (defaultTargetPlatform != TargetPlatform.android) return false;
    try {
      return await _channel
              .invokeMethod<bool>('isInstalled', {'package': package}) ??
          false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> _launchPackage(String package) async {
    try {
      return await _channel
              .invokeMethod<bool>('launch', {'package': package}) ??
          false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> _openUrl(String url) async {
    try {
      return await launchUrl(Uri.parse(url),
          mode: LaunchMode.externalApplication);
    } catch (_) {
      return false;
    }
  }

  /// a) check if installed → b) open it → c) otherwise open Google Play page.
  static Future<LaunchOutcome> open(AiApp app) async {
    final pkg = app.packageName;

    if (pkg != null) {
      // a + b: installed → open directly
      if (await isInstalled(pkg) && await _launchPackage(pkg)) {
        return LaunchOutcome.openedApp;
      }
      // c: not installed → Play Store app first, then the Play website
      if (await _openUrl(app.marketUri!)) return LaunchOutcome.openedStore;
      if (await _openUrl(app.playStoreUrl!)) return LaunchOutcome.openedStore;
    }

    // No Android app (or no store available) → web version
    if (await _openUrl(app.webUrl)) return LaunchOutcome.openedWeb;
    return LaunchOutcome.failed;
  }
}
