import 'package:flutter/material.dart';

enum AppCategory { chat, create, write, learn }

class AiApp {
  const AiApp({
    required this.id,
    required this.name,
    required this.packageName,
    required this.webUrl,
    required this.icon,
    required this.colors,
    required this.category,
    required this.descEn,
    required this.descAr,
  });

  /// Short id, also used for the optional icon file: assets/icons/<id>.png
  final String id;
  final String name;

  /// Android package name. `null` when there is no official Android app
  /// (the web version is opened instead).
  final String? packageName;

  /// Fallback website, used if neither the app nor the store can be opened.
  final String webUrl;

  final IconData icon;
  final List<Color> colors;
  final AppCategory category;
  final String descEn;
  final String descAr;

  String get iconAsset => 'assets/icons/$id.png';

  String? get playStoreUrl => packageName == null
      ? null
      : 'https://play.google.com/store/apps/details?id=$packageName';

  String? get marketUri =>
      packageName == null ? null : 'market://details?id=$packageName';

  String description(bool arabic) => arabic ? descAr : descEn;
}
