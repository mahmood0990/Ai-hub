import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Holds the current language and saves the user's choice.
class LocaleController extends ChangeNotifier {
  static const _prefKey = 'app_lang';
  Locale _locale = const Locale('ar');

  Locale get locale => _locale;
  bool get isArabic => _locale.languageCode == 'ar';

  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final code = prefs.getString(_prefKey);
      if (code == 'ar' || code == 'en') _locale = Locale(code!);
    } catch (_) {/* first run or storage unavailable – keep default */}
  }

  Future<void> toggle() async {
    _locale = isArabic ? const Locale('en') : const Locale('ar');
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefKey, _locale.languageCode);
    } catch (_) {}
  }
}

/// Makes the [LocaleController] available to the whole widget tree.
class LocaleScope extends InheritedNotifier<LocaleController> {
  const LocaleScope({
    super.key,
    required LocaleController controller,
    required super.child,
  }) : super(notifier: controller);

  static LocaleController of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<LocaleScope>()!.notifier!;
}

/// Simple bilingual string table.
class S {
  S(this.lang);
  final String lang;

  static S of(BuildContext context) =>
      S(LocaleScope.of(context).locale.languageCode);

  bool get isAr => lang == 'ar';

  static const Map<String, Map<String, String>> _t = {
    'en': {
      'appName': 'AI Hub',
      'welcomeTitle': 'Welcome to the\nWorld of AI',
      'welcomeSubtitle':
          'All the best AI apps in one calm place.\nTap any app to open it — or get it from Google Play instantly.',
      'getStarted': 'Get Started',
      'toolsCount': '15 handpicked AI tools',
      'homeTitle': 'Explore AI Tools',
      'homeSubtitle': 'Your gateway to the smartest apps',
      'search': 'Search apps…',
      'installed': 'Open',
      'notInstalled': 'Get',
      'openingApp': 'Opening',
      'openingStore': 'Not installed — opening Google Play for',
      'openingWeb': 'Opening the web version of',
      'failed': 'Could not open',
      'noResults': 'No apps match your search',
      'cat_all': 'All',
      'cat_chat': 'Assistants',
      'cat_create': 'Create',
      'cat_write': 'Write & Translate',
      'cat_learn': 'Learn & Explore',
      'langButton': 'العربية',
    },
    'ar': {
      'appName': 'بوابة الذكاء',
      'welcomeTitle': 'مرحباً بك في عالم\nالذكاء الاصطناعي',
      'welcomeSubtitle':
          'أفضل تطبيقات الذكاء الاصطناعي في مكان واحد هادئ.\nاضغط على أي تطبيق لفتحه — أو حمّله من جوجل بلاي فوراً.',
      'getStarted': 'ابدأ الآن',
      'toolsCount': '15 أداة ذكاء اصطناعي مختارة',
      'homeTitle': 'استكشف أدوات الذكاء الاصطناعي',
      'homeSubtitle': 'بوابتك إلى أذكى التطبيقات',
      'search': 'ابحث عن تطبيق…',
      'installed': 'فتح',
      'notInstalled': 'تحميل',
      'openingApp': 'جارٍ فتح',
      'openingStore': 'غير مثبّت — جارٍ فتح جوجل بلاي لتطبيق',
      'openingWeb': 'جارٍ فتح النسخة الويب من',
      'failed': 'تعذّر فتح',
      'noResults': 'لا توجد تطبيقات مطابقة لبحثك',
      'cat_all': 'الكل',
      'cat_chat': 'المساعدات',
      'cat_create': 'الإبداع',
      'cat_write': 'الكتابة والترجمة',
      'cat_learn': 'التعلّم والاستكشاف',
      'langButton': 'English',
    },
  };

  String t(String key) => _t[lang]?[key] ?? _t['en']![key] ?? key;
}
