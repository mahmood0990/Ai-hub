package com.aihub.ai_hub

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    private val channelName = "com.aihub/apps"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "isInstalled" -> {
                        val pkg = call.argument<String>("package")
                        result.success(pkg != null && isInstalled(pkg))
                    }
                    "installedOf" -> {
                        val pkgs = call.argument<List<String>>("packages") ?: emptyList()
                        result.success(pkgs.filter { isInstalled(it) })
                    }
                    "launch" -> {
                        val pkg = call.argument<String>("package")
                        result.success(pkg != null && launchApp(pkg))
                    }
                    else -> result.notImplemented()
                }
            }
    }

    /** True if the package exists on the device (needs <queries> in the manifest on Android 11+). */
    private fun isInstalled(pkg: String): Boolean = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            packageManager.getPackageInfo(pkg, 0)
        }
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    /** Opens the app's launcher screen. Returns false if it has none. */
    private fun launchApp(pkg: String): Boolean = try {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            true
        } else {
            false
        }
    } catch (e: Exception) {
        false
    }
}
